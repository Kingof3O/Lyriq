LYRIQ — Brand Asset Package
===========================

Core concept
------------
Three lyric lines crossed by a vertical playhead: synchronized lyrics in motion.
The custom Q echoes the same cursor/playhead motif.

Primary palette
---------------
Obsidian        #09090B
Carbon          #131316
Pearl           #F7F7F8
Mist Gray        #A1A1AA
Electric Violet #8B5CF6
Soft Violet     #A78BFA

Recommended usage
-----------------
- Main app icon: 03_App_Icons/PNG/lyriq-app-icon-dark-master.png
- Windows executable icon: 03_App_Icons/Windows/lyriq.ico
- Dark UI logo: 02_Logos/PNG/lyriq-logo-horizontal-color.png
- Light backgrounds: 02_Logos/PNG/lyriq-logo-horizontal-black.png
- Dark backgrounds / monochrome: 02_Logos/PNG/lyriq-logo-horizontal-white.png
- Tiny UI/tray use: 02_Logos/SVG/lyriq-symbol-*.svg
- Marketing / README hero: 04_Social/lyriq-hero-banner-16x9.png

Tagline
-------
Hear it. Read it. Understand it.

Notes
-----
The PNG/marketing visuals were generated from the approved Lyriq identity direction.
The SVG symbol files are clean geometric rebuilds for scalable UI use.
Before commercial release, run formal trademark clearance for the name "Lyriq" in your target markets.
